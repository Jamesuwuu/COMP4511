import { StatusBar } from 'expo-status-bar';
import { ImageBackground, Button, Image, StyleSheet, Text, View } from 'react-native';
import React,{ useState } from 'react';
import background from "./assets/background2.jpg"

export default function App() {
  const [toggle, setToggle] = React.useState(false);

  function Clicked() {
    setToggle(!toggle);
  }

  return (
    <View style={styles.container}>
      <ImageBackground style={styles.background} source={background} resizeMode="cover">
        <Text style={styles.text}>My name is James</Text>
        <Text>I am 22 years old</Text>
        <Text>My favourite food is salmon</Text>
        <Text>My hobby is gaming</Text>
        <Text>I wear long pants in hot weather</Text>
        {
          toggle ?
          <Image style={styles.image}/>:
          <Image 
            style={styles.image} 
            source={{uri: "https://cdn.vox-cdn.com/thumbor/Si2spWe-6jYnWh8roDPVRV7izC4=/0x0:1192x795/1400x788/filters:focal(596x398:597x399)/cdn.vox-cdn.com/uploads/chorus_asset/file/22312759/rickroll_4k.jpg"}}       
          />
        }
        <Button 
          title="Toggle Image" 
          style={{width: 100}}
          onPress={() => Clicked()}
          />
      </ImageBackground>
      <StatusBar style="auto" />
    </View>
  );
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
  },
  image: {
    height: 100,
    width: 100,
    borderRadius: 50,
    marginTop: 20,
    marginBottom: 20,
    
  },
  background: {
    flex: 1,
    justifyContent: 'center',
    width: '100%',
    alignItems: 'center',
  },
});

